# TG12_1_OOP
Klasse 12 - ITL
