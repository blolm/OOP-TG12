package A00_ÜbungKlasse;

public class ErzeugeLehrer {
    
    public static void main(String[] args) {
        
    }
}
