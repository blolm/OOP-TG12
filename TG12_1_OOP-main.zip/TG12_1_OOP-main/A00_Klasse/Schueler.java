//Bauplan für Schülerobjekte

class Schueler{

    private int groesse;
    String name;
    
    //Konstruktor
    public Schueler(){
        groesse = 175;
        name = "Mustermann";
    }

    //Getter
    public String getName(){
        return name;
    }

    public int getGroesse() {
        return groesse;
    }
}