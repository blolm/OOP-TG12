package D01WdHVererbung;

public class FilmtitelzukurzException extends Exception {
    
    public FilmtitelzukurzException(){
        super("Titel zu kurz");
    }
}
