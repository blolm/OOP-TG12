/**
 * Erzeugeschueler
 */

 public class Erzeugeschueler {

    public static void main(String[] args) {

        Schueler s1 = new Schueler();


        System.out.println(s1.getName());
        System.out.println(s1.getGroesse());

    }
}
